var input = document.querySelector("#name");
var texto = input.value;
console.log(texto);