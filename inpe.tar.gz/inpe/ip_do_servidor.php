<?php
$host= gethostname();
$ip = gethostbyname($host);

echo $ip;

?>